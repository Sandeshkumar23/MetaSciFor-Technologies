from django.contrib import admin
from .models import Hotel, Room

admin.site.register(Hotel)
admin.site.register(Room)
